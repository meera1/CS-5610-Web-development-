﻿Following are the experiments done:

- drag.html
- frames_main.html


